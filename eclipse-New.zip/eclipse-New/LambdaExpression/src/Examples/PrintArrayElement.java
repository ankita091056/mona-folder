package Examples;

public class PrintArrayElement {
	public static void main(String[]args) {
		int [] array = {12,34,65,87,98,76,55};
		System.out.println("array Elements : ");
		for(int i=0;i<array.length;i++) {
		System.out.println(array[i]);
	}
	}
}
