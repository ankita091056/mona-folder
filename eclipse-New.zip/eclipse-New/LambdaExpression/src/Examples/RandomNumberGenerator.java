package Examples;

import java.util.Random;

public class RandomNumberGenerator {
    public static void main(String[] args) {
        // Create an instance of the Random class
        Random random = new Random();

        // Generate and print 10 random numbers
        System.out.println("Random 10 numbers:");

        for (int i = 0; i < 10; i++) {
            int randomNumber = random.nextInt(); // Generates a random integer
            System.out.println(randomNumber);
        }
    }
}

