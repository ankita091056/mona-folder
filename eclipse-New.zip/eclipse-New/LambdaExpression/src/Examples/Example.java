package Examples;

import java.util.Arrays;


public class Example {
    public static void main(String[] args) {
        int[] numbers = {-32, -23, 11, 10, 15};

        int sumOfEvens = Arrays.stream(numbers)
                .filter(n -> n % 2 == 0) // Filter for even numbers
                .sum(); // Calculate the sum of even numbers

        System.out.println("The sum of even numbers is: " + sumOfEvens);
    }
}

