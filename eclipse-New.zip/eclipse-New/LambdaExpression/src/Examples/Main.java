package Examples;

class classOne {
    public classOne()
    {
        System.out.println("class one:1");
    }
}
    class classTwo extends classOne{
        public classTwo()
    {
        System.out.println("class one:2");
    } 
    }
    class classThree extends classTwo {
        public classThree()
    {
        	super();
        System.out.println("class one:3");
    } 
    }
    class Main{
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        new classTwo();
    }
}
