package Examples;

import java.util.ArrayList;

public class List {
	ArrayList<String> list = new ArrayList();
	

}
