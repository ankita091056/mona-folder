package Examples;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Employee {
    private int employeeId;
    private String employeeName;
    private double salary;

    // Constructor and other methods

    public Employee(int employeeId, String employeeName, double salary) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.salary = salary;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "employeeId=" + employeeId +
                ", employeeName='" + employeeName + '\'' +
                ", salary=" + salary +
                '}';
    }
}

public class EmployeeSortingExample {
    public static void main(String[] args) {
        // Create a list of employees
        List<Employee> employeeList = new ArrayList<>();
        employeeList.add(new Employee(101, "John Doe", 50000.0));
        employeeList.add(new Employee(102, "Jane Doe", 60000.0));
        employeeList.add(new Employee(103, "Alice Smith", 55000.0));

        // Sort the list based on employee names using Comparator
        Collections.sort(employeeList, Comparator.comparing(Employee::getEmployeeName));

        // Display the sorted list
        System.out.println("Sorted Employee List based on Names:");
        for (Employee employee : employeeList) {
            System.out.println(employee);
        }
    }
}

