package array;

public class DuplicateElement {
	public static void main(String[]args) {
	int[] array={11,22,3,4,5,55,3,2};
	System.out.println("Duplicate Elements in the array: "); 
	 for(int i = 0; i < array.length; i++) 
	 {  
         for(int j = i + 1; j < array.length; j++) 
         {  
             if(array[i] == array[j])  
                 System.out.println(array[j]);  
         }  
	}
}

}  