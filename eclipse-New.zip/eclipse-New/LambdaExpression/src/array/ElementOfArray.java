package array;

public class ElementOfArray {
	public static void main(String[]args) {
		int array[]= {1,34,24,65,87,98,9};
		System.out.println("Elements Of Array : ");
			System.out.println(array.length);
		}
	}


