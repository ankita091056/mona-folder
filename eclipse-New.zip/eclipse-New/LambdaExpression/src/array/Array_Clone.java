package array;

import java.util.Scanner;  
 
public class Array_Clone {  
 
  public static void main(String[] args)  
  {  
      
       int originalArray[];  
       int cloneArray[];  
       int size;  
       
       Scanner sc = new Scanner(System.in);  
       System.out.println("Enter the size of the array.");  
       size = sc.nextInt();  
         
        
       originalArray = new int[size];  
       cloneArray = new int[size];  
       System.out.println("Enter elements of the original array:");  
       
       for(int i = 0; i < size; i++) {  
           originalArray[i] = sc.nextInt();  
       }  
      
       sc.close();  
        
       cloneArray = originalArray.clone();  
    
   
       System.out.println("Elements of the original array:");  
       for (int i = 0; i < originalArray.length; i++) {  
           System.out.print(originalArray[i] + " ");  
       }    
     
       System.out.println("\n\nElements of the clone array:");  
       for (int i = 0; i < cloneArray.length; i++) {  
           System.out.print(cloneArray[i] + " ");  
       }  
  }  
}  