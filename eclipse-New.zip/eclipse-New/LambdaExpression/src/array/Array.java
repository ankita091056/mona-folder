package array;

public class Array {

	public static void main(String[] args) throws InterruptedException {
		int [] array = {23,11,34,56,78,99};
		int [] array2 ={23,11,34,56,78,99};
		int [] array3 = new int[6];
		System.out.println("Elements In Array : " +array3);
//		System.out.println("Elements In Array : ");
//		for(int i=0;i<array3.length;i++) {
//			System.out.println(array3[i]);
//		}
		System.out.println("Elements In Array : ");
		for(int i=0;i<array.length;i++) {
			System.out.println(array[i]);
		}
		System.out.println("Size Of array is :" + array.length);
		// TODO Auto-generated method stub
        System.out.println(array2.length);
        System.out.println(array.hashCode());
        //array.clone();
        System.out.println(array.length);
        //System.out.println(array2);
	}

}
