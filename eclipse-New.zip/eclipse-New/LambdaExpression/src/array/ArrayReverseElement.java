package array;

public class ArrayReverseElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int array [] = {12,45,65,76,98,76,5,4,3};
		System.out.println("Elements of arrray : ");
		for(int i=0;i<array.length;i++) {
			
			System.out.println(array[i]);
		}
		System.out.println("Elements of arrray in reverse order : ");
         for(int i=array.length-1;i>=0;i--) {
        	 System.out.println(array[i]);
         }
	}

}
