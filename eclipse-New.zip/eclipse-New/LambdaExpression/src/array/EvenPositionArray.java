package array;

public class EvenPositionArray {
	public static void main(String[]args) {
		int[] array= {1,2,3,4,5,9,8};
		System.out.println("Arrays in Even position : ");
		for(int i=1;i<array.length;i= i + 2) {
			System.out.println(array[i]);
		}
		
	}

}
