package array;

import java.util.Arrays;
import java.util.Scanner;

public class CheckEqualArray {
	 public static boolean equalMethod(int array1[],int array2[]) {
  	   int n = array1.length;
  	   int m= array2.length;
  	   if(n!=m) {
  		   return false;
  	   }
  	   Arrays.sort(array1);
  	   Arrays.sort(array2);
  	   for(int i=0;i<n;i++) {
  		   if(array1[i]!=array2[i]) {
  			   return false;
  		   }
  		   }
  	 return true;
  	   }
	public static void main(String[] args) {
//		 int arr1[] = { 3, 5, 2, 5, 2 };
//	       int arr2[] = { 2, 3, 5, 5, 2 };
//	 
//	        // Function call
//	        if (equalMethod(arr1, arr2))
//	            System.out.println("Yes");
//	        else
//	            System.out.println("No");
//	    }
		int[] a1 = new int[5];
        int[] a2 = new int[5];
        System.out.println("enter size of array 1");
        Scanner sc = new Scanner(System.in);
        int size1 = sc.nextInt();
        System.out.println("enter element of First Array");
        for(int i=0;i<size1;i++)
            a1[i]=sc.nextInt();
        System.out.println("enter size of array2");
        int size2=sc.nextInt();
        System.out.println("enter element of Second Array");
        for(int i=0;i<size2;i++)
           a2[i]=sc.nextInt();
       if(equalMethod(a1,a2))
            System.out.println("Both array is same");
       else
            System.out.println("arrays is not same");
     }
}
	      
	     

