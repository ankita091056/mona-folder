package array;

public class OddPositionArray {
  public static void main(String[]args) {
	  int [] array = {11,23,45,6,7,85,4};
	  System.out.println("Arrays in odd position : ");
	  for(int i=0;i<array.length;i=i+2) {
		  System.out.println(array[i]);
	  }
  }
}
