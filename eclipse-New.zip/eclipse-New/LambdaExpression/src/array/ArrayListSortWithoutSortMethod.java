package array;

import java.util.ArrayList;

public class ArrayListSortWithoutSortMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     ArrayList <Integer >list = new ArrayList<>();
     list.add(10);
     list.add(2);
     list.add(30);
     list.add(4);
     list.add(50);
     
     bubbleSort(list);
     System.out.println(list);
	}
	
     public static void bubbleSort(ArrayList<Integer> list) 
     { 
    	 int n = list.size();
    	 boolean swapped;
    	 do { 
    		 swapped = false; 
    		 for (int i = 1; i < n; i++) {
    			 if (list.get(i - 1) > list.get(i)) 
    			 { 
    				 // Swap elements 
    				 int temp = list.get(i - 1);
    				 list.set(i - 1, list.get(i));
    				 list.set(i, temp); 
    				 swapped = true; 
    				 } 
    			 }
    		 }
    	 while (swapped);
    	 }
     }
    			