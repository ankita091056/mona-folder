package array;

import java.util.Arrays;

public class SortArrayUsingMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   int[]array= {12,2,3,48,5,67,7,85,9};
	       
	        Arrays.sort(array);
	        System.out.println("Elements of array sorted in ascending order: ");  
	        for(int i=0;i<array.length;i++) {
	        	
	        	System.out.println(array[i]);
	        }

	}

}
