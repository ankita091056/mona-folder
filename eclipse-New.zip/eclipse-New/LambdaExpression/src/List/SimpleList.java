package List;

import java.util.ArrayList;
import java.util.List;

public class SimpleList {
    public static void main(String[] args) {
        List newList = new ArrayList();
        newList.add("Apple");
        newList.add("Banana");
        newList.add("Cat");
        newList.add("Bat");
        newList.add("Ball");
        newList.add("Orange");
        newList.add("Grapes");

        for (int i=0;i< newList.size();i++){
            System.out.println(newList);
        }
    }
}
