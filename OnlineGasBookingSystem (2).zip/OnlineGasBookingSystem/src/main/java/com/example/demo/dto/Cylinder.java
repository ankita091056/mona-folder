package com.example.demo.dto;

import lombok.Data;
import lombok.ToString;
@ToString
@Data
public class Cylinder {
int cylinderId;
String type;
float weigth;
String strapecolour;
float price;

}
