function userFriends(username,...arg){
    console.log("Name: "+username);
    console.log("Friends: ")
    for(i in arg){
    console.log(arg[i])
    }
}
 userFriends("sujit","sheetal","swati","nandini");
