var Order = {
    id: 10,
    title: 'order',
    prie: 100,
    printOrder: function () {
        console.log(id + " " + this.title + " " + this.price);
    },
    getPrice: function () {
        return this.prie;
    }
};
var CopyObject = Object.assign(Order);
console.log(CopyObject);
