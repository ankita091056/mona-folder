var names = ["alpha", "beta", "gamma", "delta"];
var [firstele,secondele,thirdele,fourthele]= names;
console.log(thirdele);