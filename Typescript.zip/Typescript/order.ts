var Order={
    id:10,
    title:'order',
    prie:100,
    printOrder(){
        console.log(id+" "+this.title+" "+this.price)
    },
    getPrice(){
        return this.prie;
    }
}

var CopyObject = Object.assign(Order);
console.log(CopyObject)