function userFriends(username) {
    var arg = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        arg[_i - 1] = arguments[_i];
    }
    console.log("Name: " + username);
    console.log("Friends: ");
    for (i in arg) {
        console.log(arg[i]);
    }
}
userFriends("sujit", "sheetal", "swati", "nandini");
