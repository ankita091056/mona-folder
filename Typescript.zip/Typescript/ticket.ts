let laptop_model="ACER A515";
let deskNo=10;
let name1="neeraj";

console.log(`Ticket
Problem: laptop screen is flickering
laptop Model: ${laptop_model}
deskNo: ${deskNo}
Name: ${name1}`);
