function test(num) {
    if (num % 2) {
        var x = num;
        console.log(x);
    }
    else {
        // console.log(x);  // Uncaught ReferenceError: x is not defined
    }
}
test(10);
