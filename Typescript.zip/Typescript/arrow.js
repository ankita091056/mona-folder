var StringArray = ['Ankita', 'Smita', 'Radha'];
var arrowFunction = function (StringArray) {
    var resArray = [];
    StringArray.map(function (ele) {
        var object = {
            name: "",
            length: 0
        };
        object.name = ele;
        object.length = ele.length;
        resArray.push(object);
    });
    return resArray;
};
console.log(arrowFunction(StringArray));
