function add(a,b=10){
    console.log(a+b);
}

add(10,40);
add(5);