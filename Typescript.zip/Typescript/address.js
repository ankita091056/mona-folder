var organization = {
    name: "xyz",
    address: {
        city: "NY",
        state: "NY",
        pincode: 12345
    }
};
var _a = organization.address, city1 = _a.city, state1 = _a.state, pincode1 = _a.pincode;
console.log(pincode1);
