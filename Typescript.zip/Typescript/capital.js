function printCapitalNames(name1, name2, name3, name4, name5) {
    console.log("Names after");
    console.log(name1.toUpperCase() + " " + name2.toUpperCase() + " " + name3.toUpperCase() + " " + name4.toUpperCase() + " " + name5.toUpperCase());
}
var nameList = ["john", "tom", "nik", "sam", "wick"];
console.log("Names Before: ", nameList);
printCapitalNames.apply(void 0, nameList);
