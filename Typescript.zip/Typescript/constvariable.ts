const num = 10;
 console.log(num);
