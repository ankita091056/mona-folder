var laptop_model = "ACER A515";
var deskNo = 10;
var name1 = "neeraj";
console.log("Ticket\nProblem: laptop screen is flickering\nlaptop Model: ".concat(laptop_model, "\ndeskNo: ").concat(deskNo, "\nName: ").concat(name1));
