var names = ["alpha", "beta", "gamma", "delta"];
var firstele = names[0], secondele = names[1], thirdele = names[2], fourthele = names[3];
console.log(thirdele);
