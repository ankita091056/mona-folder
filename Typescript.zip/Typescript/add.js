function add(a, b) {
    if (b === void 0) { b = 10; }
    console.log(a + b);
}
add(10, 40);
add(5);
