package com.demo.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Id;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Data
public class Emp {

    @Id
    @GeneratedValue
    private long id;
    private String username;
    private String password;
    private String Email;


}

