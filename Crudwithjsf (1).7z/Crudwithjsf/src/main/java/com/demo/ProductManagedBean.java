package com.demo;


import javax.faces.bean.SessionScoped;
import com.entities.Product;
import com.models.ProductModel;

@SessionScoped

public class ProductManagedBean {

	private Product product;

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public ProductManagedBean() {
		this.product = new Product();
	}

	public String save() {
		ProductModel productModel = new ProductModel();
		productModel.create(this.product);
		return "success?faces-redirect=true";
	}

}