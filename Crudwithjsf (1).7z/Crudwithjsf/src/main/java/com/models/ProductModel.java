package com.models;

import javax.faces.bean.ManagedBean;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.annotation.SessionScope;

import com.entities.Product;

@ManagedBean(name = "productmodel")
@Repository
@SessionScope
public class ProductModel {
	
	
	final StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure().build();
    SessionFactory factory = new MetadataSources(registry).buildMetadata().buildSessionFactory();

	

    



    @Transactional
	public String create(Product product) {
    	Session session = factory.getCurrentSession();
    	Transaction transaction = session.beginTransaction();
    	session.persist(product);
    	return "success?faces-redirect=true";
	}

}