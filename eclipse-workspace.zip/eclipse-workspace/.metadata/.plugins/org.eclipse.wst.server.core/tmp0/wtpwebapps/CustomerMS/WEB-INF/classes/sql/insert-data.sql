insert  into `EMPLOYEE_DETAIL`
(`NAME`,`CONTACT_NO`,`ADDRESS`)
values 
('Ananya','123456', 'Hyd'),
('Ananya1','12345678', 'Bang');