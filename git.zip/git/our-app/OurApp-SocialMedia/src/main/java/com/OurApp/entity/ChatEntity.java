package com.OurApp.entity;

public class ChatEntity {

}
