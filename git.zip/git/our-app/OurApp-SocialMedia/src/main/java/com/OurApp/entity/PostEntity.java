package com.OurApp.entity;

public class PostEntity {

}
