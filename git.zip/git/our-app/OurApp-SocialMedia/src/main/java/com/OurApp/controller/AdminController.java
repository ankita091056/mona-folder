package com.OurApp.controller;




import javax.persistence.Entity;
import javax.persistence.Id;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



import com.OurApp.dto.LoginDTO;
import com.OurApp.entity.AdminEntity;
import com.OurApp.service.AdminService;



@CrossOrigin
@RestController
@RequestMapping("/SMA-admin")
public class AdminController {
    
    @Autowired private AdminService aservice;
    
    @PostMapping("validate")
    public ResponseEntity<?> validate(@RequestBody LoginDTO dto) {
        System.out.println(dto);
        AdminEntity admin=aservice.validate(dto);
        if(admin==null)
            return ResponseEntity.badRequest().body("Incorrect userid or password");
        return ResponseEntity.ok(admin);
    }



}