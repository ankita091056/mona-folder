package com.OurApp.service;

public class PostService {

}
