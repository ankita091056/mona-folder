
package com.OurApp.serviceImplementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.OurApp.dto.LoginDTO;
import com.OurApp.entity.AdminEntity;
import com.OurApp.repositories.AdminRepository;
import com.OurApp.service.AdminService;



@Service
public class AdminServiceImpl implements AdminService {



   @Autowired private AdminRepository repo;
    



   @Override
    public AdminEntity validate(LoginDTO dto) {
        
        
            AdminEntity admin=repo.findById(dto.getUserid()).orElse(null);
            if(admin!=null && admin.getPwd().equals(dto.getPwd()))
                return admin;
            return null;
        }
        
    @Override
    public void register(AdminEntity admin) {
    
            if(repo.count()==0)
                repo.save(admin);
        }
        
    }

