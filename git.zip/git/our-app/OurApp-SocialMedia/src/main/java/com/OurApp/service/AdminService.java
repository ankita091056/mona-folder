
package com.OurApp.service;

import com.OurApp.dto.LoginDTO;
import com.OurApp.entity.AdminEntity;



public interface AdminService {
    AdminEntity validate(LoginDTO dto);
    void register(AdminEntity admin);
}