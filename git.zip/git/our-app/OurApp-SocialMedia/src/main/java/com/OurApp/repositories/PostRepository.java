package com.OurApp.repositories;

public class PostRepository {

}
