package com.student.management.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "student")
public class Student {
	@Id
	
	@Column(name = "student_id",unique=true)
	private long id;
	@Column(name = "student_name")
	@NotEmpty
	@Size(min=2,message="Name should have atleast two characters")
	private String name;
	@NotEmpty
	@Column(name = "student_department")
	private String department;
	@Column(name = "student_institute")
	@NotEmpty
	private String institute;
	@Column(name = "student_address")
	@NotEmpty
	private String address;

	public Student() {
		super();

	}
    
	public Student(long id, String name, String department, String institute, String address) {
		super();
		this.id = id;
		this.name = name;
		this.department = department;
		this.institute = institute;
		this.address = address;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getInstitute() {
		return institute;
	}

	public void setInstitute(String institute) {
		this.institute = institute;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", department=" + department + ", institute=" + institute
				+ ", address=" + address + "]";
	}

}
