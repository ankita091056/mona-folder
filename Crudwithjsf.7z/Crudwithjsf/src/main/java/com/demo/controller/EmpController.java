package com.demo.controller;

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RestController;

	import com.demo.entity.Emp;
	import com.demo.service.EmpService;

	@RestController
	public class EmpController {
		@Autowired
		private EmpService empService;

		@PostMapping("/addEmp")
		public Emp addEmp(@RequestBody Emp emp) {
			return empService.createEmp(emp);
		}

		@PostMapping("/addEmps")
		public List<Emp> addUsers(@RequestBody List<Emp> emp) {
			return empService.createEmp(emp);
		}

		@GetMapping("/emp/{id}")
		public Emp getEmpById(@PathVariable long id) {
			return empService.getEmpById(id);
		}

		@GetMapping("/emps")
		public List<Emp> getAllEmp() {
			return empService.getEmp();
		}
		
		@PutMapping("/updateemp")
		public Emp updateUser(@RequestBody Emp emp) {
			return empService.updateEmp(emp);
		}

		@DeleteMapping("/emp/{id}")
		public String deleteEmp(@PathVariable long id) {
			return empService.deleteEmpById(id);
		}
	}



