package com.demo.dao;

import com.demo.entity.Emp;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmpRepository extends JpaRepository<Emp, Long> {
	  

}
