package com.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.EmpRepository;
import com.demo.entity.Emp;

@Service
public class EmpService {
@Autowired
private EmpRepository empRepository;

public Emp createEmp(Emp emp) {
	return empRepository.save(emp);
}
public List<Emp> createEmp(List<Emp> emp) {
	return empRepository.saveAll(emp); 

}
public Emp getEmpById(long id) {
	return empRepository.findById(id).orElse(null);

}
public List<Emp> getEmp() {
	return empRepository.findAll();
}
public Emp updateEmp(Emp emp) {
	Emp oldEmp=null;
	Optional<Emp> optionalemp=empRepository.findById(emp.getId());
	if(optionalemp.isPresent()) {
		oldEmp=optionalemp.get();
		oldEmp.setUsername(emp.getUsername());
		oldEmp.setEmail(emp.getEmail());
		oldEmp.setPassword(emp.getPassword());
		empRepository.save(oldEmp);
	}else {
		return new Emp();
	}
	return oldEmp;
}

public String deleteEmpById(long id) {
	empRepository.deleteById(id);
	return "User got deleted";
}

}

