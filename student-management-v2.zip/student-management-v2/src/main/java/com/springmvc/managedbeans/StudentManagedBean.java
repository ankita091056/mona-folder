package com.springmvc.managedbeans;
import java.util.List;

import javax.faces.bean.RequestScoped;

import com.springmvc.model.Student;
import com.springmvc.service.StudentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("sBean")
@RequestScoped
public class StudentManagedBean {
	
	@Autowired
	private StudentService studentService;
	
	@Autowired
	private Student student;

	
	public String redirectAddStudent() {
		this.resetStudentData();
		return "addStudent?faces-redirect=true";
	}
	
	public String redirectEditStudent(Long studentId) {
		System.out.println("editing student for "+studentId);
		Student eStudent = studentService.getStudentById(studentId);
		this.student.setStudentId(eStudent.getStudentId());
		this.student.setStudentName(eStudent.getStudentName());
		this.student.setStudentEmail(eStudent.getStudentEmail());
		this.student.setStudentGPA(eStudent.getStudentGPA());
		return "editStudent?faces-redirect=true";
	}
	
	
	public String addNewStudent() {
		System.out.println(student.toString());
		studentService.save(student);
		this.resetStudentData();
		return "viewStudents?faces-redirect=true";
	}
	
	public String updateStudent() {
		System.out.println("student id for update "+student);
		studentService.updateStudent(student.getStudentId(), student);
		this.resetStudentData();
		return "viewStudents?faces-redirect=true";
	}
	
	public String deleteStudent(Long studentId) {
		studentService.removeStudent(studentId);
		System.out.println("deleted student with id "+studentId);
		return "viewStudents?faces-redirect=true";
	}
	
	public List<Student> getStudentList() {
		return studentService.getStudentList();
	}
	
	public void resetStudentData() {
		this.student.setStudentId(null);
		this.student.setStudentName(null);
		this.student.setStudentEmail(null);
		this.student.setStudentGPA(null);
	}
}
