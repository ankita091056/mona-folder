package com.springmvc.dao;

import java.util.List;

import com.springmvc.exception.DaoException;
import com.springmvc.model.Student;

public interface StudentDao {
	
	void saveStudent(Student student);
	void updateStudent(Long studentId,Student newStudent);
	void deleteStudent(Long studentId);
	
	Student getStudentById(Long studentId);
	List<Student> getStudentList();
}
