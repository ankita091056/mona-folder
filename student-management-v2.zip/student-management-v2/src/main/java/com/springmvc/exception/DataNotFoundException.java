package com.springmvc.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND , reason = " Requesting data is not Found !")
public class DataNotFoundException extends Exception {
	private static final long serialVersionUID = -3332292346834265371L;

	public DataNotFoundException(int id){
		super("Student not found with id="+id);
	}
}
