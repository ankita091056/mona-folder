package com.example.demo.dto;


import lombok.Data;

@Data
public class Response<T> {
	private T data;
	private String status;
	private AppError error;

	public String getStatus() {
		return error != null ? "ERROR" : "SUCCESS";
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public AppError getError() {
		return error;
	}

	public void setError(AppError error) {
		this.error = error;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	

}

