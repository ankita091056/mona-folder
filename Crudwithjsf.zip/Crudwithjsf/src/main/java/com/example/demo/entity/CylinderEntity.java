package com.example.demo.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.ToString;

	@Entity
	@Table(name = "cylinder2")
	@Data
	@ToString
	public class CylinderEntity {


		    @Id
		    @GeneratedValue(strategy = GenerationType.IDENTITY)
		    @Column(name="cylinderId")
		    private int cylinderId;

		    @Column(name="type")
		    private String type;

		    @Column(name= "weigth")
		    private float weigth;

		    @Column(name="strapecolour")
		    private String strapecolour;
  
		    @Column(name="price")
		    private float price;

			public int getCylinderId() {
				return cylinderId;
			}

			public void setCylinderId(int cylinderId) {
				this.cylinderId = cylinderId;
			}

			public String getType() {
				return type;
			}

			public void setType(String type) {
				this.type = type;
			}

			public float getWeigth() {
				return weigth;
			}

			public void setWeigth(float weigth) {
				this.weigth = weigth;
			}

			public String getStrapecolour() {
				return strapecolour;
			}

			public void setStrapecolour(String strapecolour) {
				this.strapecolour = strapecolour;
			}

			public float getPrice() {
				return price;
			}

			public void setPrice(float price) {
				this.price = price;
			}

			
	}
