package com.springmvc.controller;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import com.springmvc.exception.DataNotFoundException;
import com.springmvc.model.Student;
import com.springmvc.service.StudentService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@ManagedBean(name="studentBean")
@Component("sBean")
@RequestScoped

public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	
	private Student student = new Student();
	
	 
	public String redirectAddStudent(Student student) {
		this.resetStudentData(student);
		return "addStudent?faces-redirect=true";
	}
	


	public String redirectEditStudent(Long studentId) {
	System.out.println("editing student for "+studentId);
		Student eStudent = studentService.getStudentById(studentId);
		this.student.setStudentId(eStudent.getStudentId());
		this.student.setStudentName(eStudent.getStudentName());
		this.student.setStudentEmail(eStudent.getStudentEmail());
		this.student.setStudentGPA(eStudent.getStudentGPA());
		this.getStudent();
		return "editStudent?faces-redirect=true";
	}
	
	
	public String addNewStudent(Student student) {
		System.out.println(student.toString());
		try {
			studentService.save(student);
		} catch (DataNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.resetStudentData(student);
		return "viewStudents?faces-redirect=true";
	}
	
	public String updateStudent(Student student) {
		System.out.println("student id for update "+student);
		studentService.updateStudent(student.getStudentId(), student);
		this.resetStudentData(student);
		return "viewStudents?faces-redirect=true";
	}
	
	public String deleteStudent(Long studentId) {
		studentService.removeStudent(studentId);
		System.out.println("deleted student with id "+studentId);
		return "viewStudents?faces-redirect=true";
	}
	
	public List<Student> getStudentList() {
       return studentService.getStudentList();
	}
	
	public void resetStudentData(Student student) {
		student.setStudentId(null);
		student.setStudentName(null);
	    student.setStudentEmail(null);
	    student.setStudentGPA(null);
	}
	public Student getStudent() {
		return student;
	}

	
}

