package com.springmvc.dao;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springmvc.model.Student;

@Repository
public class StudentDaoImpl implements StudentDao {
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void saveStudent(Student student)  {
		try {
			Session session = sessionFactory.openSession();
			session.beginTransaction();
			Long studentId = (Long) session.save(student);
			session.getTransaction().commit();
			if(studentId>0) {
				System.out.println(" Student data saved with "+studentId);
			}
		} catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		
	}

	@Override
	public void updateStudent(Long studentId, Student newStudent)  {
		try {
			Session session = sessionFactory.openSession();
			Student student = session.get(Student.class, studentId);
			if(student!=null) {
				student.setStudentEmail(newStudent.getStudentEmail());
				student.setStudentGPA(newStudent.getStudentGPA());
				student.setStudentName(newStudent.getStudentName());
				session.beginTransaction();
				session.update(student);
				session.getTransaction().commit();
				System.out.println(" Student details are updated successfully !");
			} else {
				System.out.println(" student details doensn't exist");
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
	}

	@Override
	public void deleteStudent(Long studentId) {
		try {
			Session session = sessionFactory.openSession();
			Student student = session.get(Student.class, studentId);
			if(student!=null) {
				session.beginTransaction();
				session.delete(student);
				session.getTransaction().commit();
				System.out.println(" Student details are deleted successfully !");
			} else {
				System.out.println(" student details doensn't exist");
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		
		
	}

	@Override
	public Student getStudentById(Long studentId) {
		try {
			Session session = sessionFactory.openSession();
			Student student = session.get(Student.class, studentId);
			return student;
		} catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		return null;
	}

	
	
	@Override
	public List<Student> getStudentList() {
		try {
			Session session = sessionFactory.openSession();
			CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
			CriteriaQuery<Student> criteriaQuery = criteriaBuilder.createQuery(Student.class);
			Root<Student> root = criteriaQuery.from(Student.class);
			
			CriteriaQuery<Student> criteriaQuery2 = criteriaQuery.select(root);
			Query<Student> query = session.createQuery(criteriaQuery2);
			List<Student> studentList = query.getResultList();
			return studentList;
		} catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		return null;
		
	}

	}
