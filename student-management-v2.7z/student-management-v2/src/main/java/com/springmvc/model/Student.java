package com.springmvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "students")
public class Student {
	

	
	@Id
	
	@GeneratedValue(generator = "student_sequence",strategy = GenerationType.AUTO)
	@Column(name = "student_id")
	private Long studentId;
	@Column(name="student_name")
	private String studentName;
	@Column(name="student_email")
	private String studentEmail;
	@Column(name="student_gpa")
	private Integer studentGPA;
	
	public Student()
	{
		
	}
	public Student(Long studentId, String studentName, String studentEmail, Integer studentGPA) {
		
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentEmail = studentEmail;
		this.studentGPA = studentGPA;
	}
	
	public Student(Long studentId) {
		
		this.studentId = studentId;
	}
	public Long getStudentId() {
		return studentId;
	}
	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentEmail() {
		return studentEmail;
	}
	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}
	public Integer getStudentGPA() {
		return studentGPA;
	}
	public void setStudentGPA(Integer studentGPA) {
		this.studentGPA = studentGPA;
	}
	

	
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", studentEmail=" + studentEmail
				+ ", studentGPA=" + studentGPA + "]";
	}
	
	
}
