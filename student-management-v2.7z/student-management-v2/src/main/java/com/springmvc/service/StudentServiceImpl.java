package com.springmvc.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


import com.springmvc.dao.StudentDao;
import com.springmvc.exception.DataNotFoundException;
import com.springmvc.model.Student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceImpl implements StudentService , Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Autowired
	private StudentDao studentDao;
	
	
	@Override
	public void save(Student student){	
		int a=0;
		List<Student> studentList = studentDao.getStudentList();
		
		for (Student s : studentList) {
			if(s.getStudentName().equals(student.getStudentName())) {
				a++;
			}
		}
		
		if(a==0) {
			System.out.println("student dao saving..");
			studentDao.saveStudent(student);
		}else {
			System.out.println("student is already exist");
		}
	}

	@Override
	public Student getStudentById(Long studentId) {
		Student student = studentDao.getStudentById(studentId);
		return student;
	}

	
	@Override
	public List<Student> getStudentList() {
		System.out.println(this.studentDao);
		List<Student> studentList = studentDao.getStudentList();
		return studentList;
	}

	@Override
	public void updateStudent(Long studentId, Student newStudent) {
		studentDao.updateStudent(studentId, newStudent);
	}

	@Override
	public void removeStudent(Long studentId) {
		Student student = getStudentById(studentId);
		if(student!=null) {
			studentDao.deleteStudent(studentId);
		}
	}



}
