package com.springmvc.service;

import java.util.List;

import com.springmvc.exception.DataNotFoundException;
import com.springmvc.model.Student;

public interface StudentService {
	void save(Student student) throws DataNotFoundException;
	Student getStudentById(Long studentId);
	List<Student> getStudentList();
	void updateStudent(Long studentId,Student newStudent);
	void removeStudent(Long studentId);
	
}
