package com.example.StudentMSystemDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentMSystemDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
