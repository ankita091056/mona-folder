package com.example.StudentMSystemDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentMSystemDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentMSystemDemoApplication.class, args);
	}

}
