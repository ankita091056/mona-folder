package com.capg;

import java.util.Scanner;

public class ReadNumber {
	static long number;
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		try {
			System.out.println("Enter the number");
			number = scan.nextLong();	
			System.out.println("The number is "+number);
		}catch(Exception e) {	
			 System.out.println("Only Digits are allowed");    
		}
		
	}
}
