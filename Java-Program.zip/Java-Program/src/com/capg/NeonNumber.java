package com.capg;

import java.util.Scanner;

public class NeonNumber {
	 public static void main(String[] args){
	        
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter the number : ");
	        int num = sc.nextInt();
	        
	        // Finding the square root
	        int sqr = num * num;
	        
	        int sum;
	        
	        // Finding the sum
	        for (sum = 0; sqr > 0; sqr /= 10){
	            int rem = sqr % 10;
	            sum = sum + rem;
	        }
	        
	        // Checking whether sum is equals to original number
	        if (sum == num){
	            System.out.println(""+num+" is a neon number.");
	        }
	        else{
	             System.out.println(""+num+" is a NOT neon number.");
	        }
	    }
	    
}
