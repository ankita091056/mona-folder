package com.capg;

import java.util.*;
public class Hello 
{
    public static void main(String[] args)
    {
        //Let's make a List first. 
        List<String>  MyList = (List<String>) Arrays.asList("Hello","World");
        ArrayList<String> a1 = new ArrayList<String>(MyList);
       
    }
}