package com.student;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.persistence.Entity;

import org.springframework.boot.autoconfigure.integration.IntegrationProperties.RSocket.Client;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.student.controller.StudentClient;


@ManagedBean
@ApplicationScoped
public class Student {
	private long id;
	private String name;
	private String department;
	private String institute;
	private String address;
	private StudentClient client;
    private List<Student>studentList;

	public Student() {

	}

	public Student(long id, String name, String department, String institute, String address) {

		this.id = id;
		this.name = name;
		this.department = department;
		this.institute = institute;
		this.address = address;

	}



	public void setStudentList(List<Student> studentList) {
		this.studentList = studentList;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getInstitute() {
		return institute;
	}

	public void setInstitute(String institute) {
		this.institute = institute;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void createStudent() {
		System.out.println("Create Method called successfully......!!");
		client = new StudentClient();
		client.addStudent(this);
		
	}

	public String view() {
		System.out.println("get all Method called successfully......!!");
		client = new StudentClient();
		return client.getAll(this);
		
	}

	public void getById() {
		System.out.println("get by id Method called successfully......!!");
		client = new StudentClient();
		 client.getById(id);
	}

	public void updateStudent() {
		System.out.println("Update Method called successfully......!!");
		client = new StudentClient();
		client.updateStudent(this, id);
	}

	public void deleteStudent() {
		System.out.println("Delete Method called successfully......!!");
		client = new StudentClient();
		client.deleteStudent(id);
	}
	@JsonBackReference
	public List<Student> getStudentList() {
		client = new StudentClient();
		return client.getAllList(this);
		
		
	}

}
