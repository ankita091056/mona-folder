package com.student.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.student.Student;

public class StudentClient {
	private final String GET_ALL = "http://localhost:8089/student/getAllStudents";
	private final String GET_BY_ID = "http://localhost:8089/student/getbyid/{id}";
	private final String ADD = "http://localhost:8089/student/addStudent";
	private final String UPDATE = "http://localhost:8089/student/update/{id}";
	private final String DELETE = "http://localhost:8089/student/delete/{id}";
	RestTemplate template = new RestTemplate();

	public String getAll(Student student) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
		ResponseEntity<String> response = template.exchange(GET_ALL, HttpMethod.GET, entity, String.class);
		return response.getBody();
	}

	public Student addStudent(Student student) {
		ResponseEntity<Student> response = template.postForEntity(ADD, student, Student.class);
		return response.getBody();
	}
	
	public Student getById(long id) {
		
		Map<String, Long> param = new HashMap<>();
		param.put("id", id);
	    return template.getForObject(GET_BY_ID, Student.class, param);

	}

	public void updateStudent(Student student, long id) {
		template.put(UPDATE, student, id);

	}

	public void deleteStudent(long id) {
		template.delete(DELETE, id);
	}
	@JsonManagedReference
	public List<Student> getAllList(Student student) {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
		ResponseEntity<List<Student>> response = template.exchange(GET_ALL, HttpMethod.GET, entity,
				new ParameterizedTypeReference<List<Student>>() {
				});
		return response.getBody();
		
	}

}
