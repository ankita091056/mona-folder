package com.student.management.service;

import java.util.List;
import java.util.Optional;

import com.student.management.entity.Student;

public interface StudentService {
	public List<Student> getAllStudents();

	public Optional<Student> getStudentById(Long id);

	public void addStudent(Student student);

	public void updateStudent(Student student, Long id);

	public void deleteStudent(long id);

	public void deleteAllStudent();

}
