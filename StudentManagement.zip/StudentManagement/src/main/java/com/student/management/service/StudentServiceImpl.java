package com.student.management.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.student.management.entity.Student;
import com.student.management.repository.StudentRepository;
@Service
public class StudentServiceImpl implements StudentService{
    @Autowired
	private StudentRepository repo;
	@Override
	public List<Student> getAllStudents() {
		
		return repo.findAll();
	}

	@Override
	public Optional<Student> getStudentById(Long id) {
		
		return repo.findById(id);
	}

	@Override
	public void addStudent(Student student) {
		repo.saveAndFlush(student);
		
	}

	@Override
	public void updateStudent(Student student, Long id) {

    	Student stu=repo.findById(id).get();
    	stu.setName(student.getName());
    	stu.setDepartment(student.getDepartment());
    	stu.setInstitute(student.getInstitute());
    	stu.setAddress(student.getAddress());
        repo.save(stu);
    	
		
	}

	@Override
	public void deleteStudent(long id) {
	repo.deleteById(id);
		
	}

	@Override
	public void deleteAllStudent() {
		repo.deleteAll();
		
	}

}
