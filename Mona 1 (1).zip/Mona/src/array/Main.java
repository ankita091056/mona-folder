//package array;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.stream.Collectors;
//
//public class Main {
//    public static void main(String[] args) {
//        // Create employees
//        Employee employee1 = new Employee(1, "Smita", 5000);
//        Employee employee2 = new Employee(2, "Nisha", 6000);
//        Employee employee3 = new Employee(3, "Sheethal", 4500);
//
//        // Create departments
//        Department department1 = new Department(100, "Software devoloper", "New York");
//        Department department2 = new Department(200, "Frontend Developer", "London");
//
//        // Add employees to departments
//        ((Department) department1).getEmployees().add(employee1);
//        ((Department) department1).getEmployees().add(employee2);
//        ((Department) department2).getEmployees().add(employee3);
//
//        // Create a list of departments
//        List<Department> departments = new ArrayList<>();
//        departments.add(department1);
//        departments.add(department2);
//
//        // Filter employees by salary using flatMap
//        List<Employee> filteredEmployees = departments.stream()
//                .flatMap(department -> department.getEmployees().stream())
//                .filter(employee -> employee.getEmployeeSalary() > 1000)
//                .collect(Collectors.toList());
//
//        // Print filtered employees
//        for (Employee employee : filteredEmployees) {
//            System.out.println("Employee ID: " + employee.getEmployeeId());
//            System.out.println("Employee Name: " + employee.getEmployeeName());
//            System.out.println("Employee Salary: " + employee.getEmployeeSalary());
//            System.out.println("-------------------");
//        }}}