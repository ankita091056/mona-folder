package array;

import java.util.ArrayList;
import java.util.List;

public class NewArray1 {

	public static void main(String[] args) {
		int[] array = { 5, 10, 6, 7, 3, 1, 2 };
		List<Integer> output = new ArrayList<>();

		for (int i = 0; i < array.length - 1; i++) {
			if (array[i] > array[i + 1]) {
				output.add(array[i + 1]);
			}
		}

		output.add(-1);
		System.out.println(output);
	}
}
