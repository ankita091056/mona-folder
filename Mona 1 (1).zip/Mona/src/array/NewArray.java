package array;

public class NewArray {

	public class Main {
		
	    public static void main(String[] args) {
	        int[] array = {5, 10, 6, 7, 3, 1, 2};

	        for (int i = 0; i < array.length - 1; i++) {
	            if (array[i] > array[i + 1]) {
	                System.out.print(array[i + 1] + " ");
	            }
	        }

	        System.out.println("-1");
	    }
	}

}
	







