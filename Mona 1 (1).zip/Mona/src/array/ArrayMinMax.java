package array;

public class ArrayMinMax {
	
	    public static void main(String[] args) {
	        int[] array = {2, 4, 5, 6, 90, 0, 0, 0};

	        int max = array[0];
	        int min = array[0];

	        for (int i = 1; i < array.length; i++) {
	            if (array[i] > max) {
	                max = array[i];
	            }
	            if (array[i] < min) {
	                min = array[i];
	            }
	        }

	        System.out.println("Maximum value: " + max);
	        System.out.println("Minimum value: " + min);
	    }
	}


