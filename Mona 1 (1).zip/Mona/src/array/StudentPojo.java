package array;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Student implements Comparable<Student> {
	private int sId;
	private String sName;
	private int rollNumber;

	public Student(int sId, String sName, int rollNumber) {
		this.sId = sId;
		this.sName = sName;
		this.rollNumber = rollNumber;
	}

	public int getsId() {
		return sId;
	}

	public String getsName() {
		return sName;
	}

	public int getRollNumber() {
		return rollNumber;
	}

	@Override
	public int compareTo(Student other) {
		
		
		// Sort in descending order based on rollNumber
		return other.getsName().compareToIgnoreCase(this.sName) ;
	}
}

public class StudentPojo {
	public static void main(String[] args) {
		List<Student> studentList = new ArrayList<>();
		studentList.add(new Student(1, "Smita", 101));
		studentList.add(new Student(2, "Nisha", 103));
		studentList.add(new Student(3, "Sheethal", 102));

		// Sort the studentList in descending order by rollNumber
		Collections.sort(studentList);

		// Print the sorted list
		for (Student student : studentList) {
			System.out.println("Student ID: " + student.getsId());
			System.out.println("Student Name: " + student.getsName());
			System.out.println("Roll Number: " + student.getRollNumber());
			System.out.println("-----------------------------");
		}
	}
}
