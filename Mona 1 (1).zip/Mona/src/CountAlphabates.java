import java.util.HashMap;

public class CountAlphabates {
	    public static void main(String[] args) {
//	    write a program to Count the number of alphabets in a given sentence
//	    i/p="Capgemini"
//	    o/p = {C-1,a-1,p-1,g-1,e-1,m-1,i-2,n-1}
	        String str = "capgemini";
	        int size = str.length() - 1;
	        HashMap<Character, Integer> map = new HashMap<>();
	        for (int i = 0; i < size; i++) {
	            if (map.containsKey(str.charAt(i))) {
	                int count = map.get(str.charAt(i));
	                map.put(str.charAt(i), ++count);
	            } else {
	                map.put(str.charAt(i), 1);
	            }
	        }
	        System.out.println(map);
	    }
	}


