
public class HelloWorld101 {

	public static void main(String[] args) {
		
		//1st
		for(int i=0;i<=10;i++) {
			System.out.println("hello world"+i);
		}
		
		//2nd
		System.out.println("hello world/n".repeat(10));
		
	

		//3rd
		for(int i=0;i<=10;i++) {
			System.out.println("hello world");
		}
		
		//4th
		String a="hello world";
		int i=0;
		while(i<=10) {
			System.out.println(a);
			i++;
		}
		
		
		StringBuilder sc=new StringBuilder();
		for(int j=0;i<10;i++) {
		sc.append("Hello World");}
	System.out.println(sc.toString());
		
	}
	
	

}
