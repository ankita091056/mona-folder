public class MultipleCatchBlock {

 

    public static void main(String[] args) {
        // TODO Auto-generated method stub
//        Write a Java program to illustrate multiple catch block 
        try{    
            String s=null;  
            System.out.println(s.length());  
           }    
           catch(ArithmeticException e)  
              {  
               System.out.println("Arithmetic Exception occurs");  
              }    
           catch(NullPointerException e)  
              {  
               System.out.println("NullPointerException Exception occurs");  
              }    
           catch(Exception e)  
              {  
               System.out.println("Parent Exception occurs");  
              }             

}  
}  


