
public class RemoveSpecificCharacter {

 

    public static void main(String[] args) {
        // TODO Auto-generated method stub
//Write a Java program to remove a specified character from a given string.
//Original string:
//    abcdefabcdeabcdaaa
//remove char from given string :  "a"
//Second string:
//bcdefbcdebcd
        String str ="abcdefabcdeabcdaaa";
        int size = str.length();
        char ch ='a';
        String str2="";
        for(int i=0;i<size;i++) {
            if(str.charAt(i)!=ch) {
                str2=str2+str.charAt(i);
            }
        }
            System.out.print(str2);
        }
    }