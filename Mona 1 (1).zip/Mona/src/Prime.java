import java.util.Scanner;
public class Prime {

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a num");
		 int a=sc.nextInt();
		 int temp = 0;
		
		for(int i=2;i<=(a-1);i++) {
		if(a%i==0) {
			temp=temp+1;	
		}}
		if(temp>0) {
			System.out.println("not prime");
		}else {
			System.out.println("prime");
		}
			
		}}
		


	


