
public class HelloWorld10 {
	
	 public static void main(String []args)
	 {
	 System.out.println("Hello World\n ".repeat(10));
	 }
	 }

