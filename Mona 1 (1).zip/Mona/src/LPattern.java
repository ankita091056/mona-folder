
public class LPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
////        Display a L shape * symbol.
//

int n = 5;
for (int i = 0; i <= 5; i++) {
	for (int j = 0; j <= i; j++) {
		
			System.out.print("*");	

	}
	System.out.println();}}}