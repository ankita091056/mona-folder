
public class LPattern1 {

	public static void main(String[] args) {
		
		Pattern1(4);
	}
		 static void Pattern1(int n) {
			
		for(int row=1;row<=n;row++) {
			for(int col=1;col<=row;col++) {
				System.out.println("* ");
			}
			System.out.print("");
		}
	}
}

