package inheritance;

class Test {
//
//	public static void display() {
//		System.out.println("static or class method from base");
//	}
//
//	public void print() {
//		System.out.println("non static or instance method from base");
//	}
//
//}
//
//class Derived extends Base {
//
//	public static void display() {
//		System.out.println("static or class method from derived");
//	}
//
//	public void print() {
//		System.out.println("non static or instance method from derived");
//	}
//}
//
//class Test {
//	public static void main(String args[]) {
//		{
//			Base obj = new Derived();
//			obj.display();
//			obj.print();
//		}
//	}
//}



 static String greet() {
	 return greet();
 }
 
 public static void main(String[] args) {
	String ans="hello";
	System.out.println(ans);
}}



