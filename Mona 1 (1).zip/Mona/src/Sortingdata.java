import java.util.Arrays;

public class Sortingdata {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   String str[]={"Green","Banana","Mango","Apple"};
   Arrays.sort(str);
   System.out.println(Arrays.toString(str));
	}

}
