
public class MyIntroduction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("My name is smita");
System.out.println("My Age is 24");
System.out.println("My blood group  is 'A' ");
System.out.println("My salary is 50000");
System.out.println("My deapartment is Civil");

	}

}
