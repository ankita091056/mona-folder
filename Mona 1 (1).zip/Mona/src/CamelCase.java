import java.util.Scanner;

public class CamelCase {

 

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string");
        String name = sc.nextLine();
        String name2 = " ";
        for (int i = 0; i < name.length(); i++) {
            if (name.charAt(i) == ' ') {
                i++;
                char ch = (char) (name.charAt(i) - 32);
                name2 = name2 + ch;
            } else {
                name2 = name2 + name.charAt(i);
            }
        }
        System.out.println(name2);
//}
    }
}