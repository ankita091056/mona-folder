
public class Replace {
	public static void main(String[] args) {
		
	
	
	String s = "apple";  
    String s1 = s.replace("a","o"); // Replace 'h' with 's'  
    System.out.println(s1); 
    s1 = s1.replace("p","q"); // Replace 's' with 'h'  
    System.out.println(s1);  

   }  }