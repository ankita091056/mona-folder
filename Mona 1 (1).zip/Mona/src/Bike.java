
abstract class Bike
{  
	
  abstract void run();  
  
  
}  

