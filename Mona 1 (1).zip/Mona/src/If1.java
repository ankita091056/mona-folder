
public class If1 {

	public static void main(String[] args) {
		System.out.println("main begins");
		int a=10;
		if(a<0) {
			System.out.println("it is negative");
		}
		System.out.println("main ends");
	}
	}
