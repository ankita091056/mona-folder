

	import java.util.Arrays;

public class Permutation {
    public static void main(String[] args) {
        int[] nums = {1, 2, 3};
        permute(nums);
    }

    public static void permute(int[] nums) {
        permuteHelper(nums, 0);
    }

    private static void permuteHelper(int[] nums, int start) {
        if (start == nums.length - 1) {
            System.out.println(Arrays.toString(nums));
        } else {
            for (int i = start; i < nums.length; i++) {
                swap(nums, start, i);
                permuteHelper(nums, start + 1);
                swap(nums, start, i); // Backtracking
            }
        }
    }

    private static void swap(int[] nums, int i, int j) {
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }
}

