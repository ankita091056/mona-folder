import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicateElements {

 

    public static void main(String[] args) {
        // TODO Auto-generated method stub
//         Write a program to remove the duplicate 
//         elements from a list =[2,3,3,3,65,4,3,3,2]
        List list = Arrays.asList(2, 3, 3, 3, 65, 4, 3, 3, 2);
        Set<Integer> set = new HashSet<Integer>();
        set.addAll(list);
        System.out.println(set);    
    }
}