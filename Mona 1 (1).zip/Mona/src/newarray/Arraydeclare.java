package newarray;

import java.util.Scanner;

public class Arraydeclare {

	public static void main(String[] args) {
				int [] arr=new int[5];
////		System.out.println(arr[3]);
//		
//		String []arr=new String[4];
//		System.out.println(arr[2]);
//		
//		arr[0]=22;
//		arr[1]=44;
//		arr[2]=45;
//		arr[3]=56;
//		arr[4]=88;
//		System.out.println(arr[2]);
		
	   
		Scanner sc=new Scanner(System.in);
		System.out.println("enter number");
		
		
		for(int i=0;i<arr.length;i++) {
			arr[i]=sc.nextInt();
			System.out.println(arr[i]);
		}
	}

}
