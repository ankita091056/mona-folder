import java.util.*;
import java.util.Scanner;
public class ReverseString1 {
	
	
	public static void main(String[] args) {
		
//	System.out.println("enter your name");
//	
//	Scanner str=new Scanner(System.in);
//	
//	
	
	
	String str="abcdaaarq";
    String rev= " ";
    char ch ;
    for(int i=str.length()-1; i>=0;i--) {
        ch=str.charAt(i);
        rev=rev+ch;


    }
    System.out.println("rev: " +rev);

	
	
	String str1 = "bcdaaarq";
	char s = 'a';
	int count = 0;

	for (int i = 0; i < str1.length(); i++) {

		if (str.charAt(i) == s) {
			count++;

		}
	}

	System.out.println(count);

}

}
    
	
	
