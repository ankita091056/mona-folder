
public class Swap {

	public static void main(String[] args) {

		// with using third variable
		int a = 10, b = 20;
		int c;

		c = a;
		a = b;
		b = c;
		System.out.println("a =" + a);
		System.out.println("b =" + b);

		// without using third variable

		int x = 20, y = 40;

		x = x + y;
		y = x - y;
		x = x - y;
		System.out.println("x=" + x);
		System.out.println("y=" + y);

	}

}
