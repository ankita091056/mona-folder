
public class If2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double d=3.46;
	
	
		if(d>0) {
			System.out.println("it is positive");
		}
		else {
			System.out.println("it is negative");
			
		}
		System.out.println("main ends");

	}

}
			