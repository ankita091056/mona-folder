import java.util.Scanner;

public class LargestNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int n1=10;
//		int n2=20;
//		
		Scanner sc=new Scanner(System.in);
	    System.out.println("enter 1st num");
	    int n1=sc.nextInt();
	    System.out.println("enter 2nd num");
	    int n2=sc.nextInt();
	    
	    if(n1>n2) {
	    	System.out.println(n1+" is  the largest num ");
	    }else {
	    	System.out.println(n2+" is  the largest num ");
	    }
		

	}

}
