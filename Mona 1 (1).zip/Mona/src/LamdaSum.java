
public class LamdaSum {
    public static void main(String[] args) {
        // Define a lambda expression to find the sum of two integers
        SumCalculator sumCalculator = (a, b) -> a + b;

        // Test the lambda expression
        int num1 = 5;
        int num2 = 3;
        int sum = sumCalculator.calculateSum(num1, num2);
        System.out.println("Sum: " + sum);
    }

    // Functional interface for sum calculation
    @FunctionalInterface
    interface SumCalculator {
        int calculateSum(int a, int b);
    }
}








