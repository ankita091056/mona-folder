
public class CountWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "not last but least";
		int count = 0;
		int size = str.length();
		for (int i = 0; i < size; i++) {
			if (str.charAt(i) != ' ') {
				count++;

			}
		}
		System.out.println(count);
	}
}
