
public class CountVowel {

 

    public static void main(String[] args) {
        // TODO Auto-generated method stub

 

//Reverse a String called “Capgemini Training” 
//Count the number of Vowels in it
        String str ="Capgemini Training";
        int size=str.length()-1;
        String str2="";
        int count=0;
        for(int i=size;i>0;i--) {
            str2=str2+str.charAt(i);
             if (str.charAt(i) == 'a' || str.charAt(i) == 'e'
                        || str.charAt(i) == 'i'
                        || str.charAt(i) == 'o'
                        || str.charAt(i) == 'u') {
            count++;
            }
        }
            System.out.println(str2);
            System.out.println(count);
        }
    }

 