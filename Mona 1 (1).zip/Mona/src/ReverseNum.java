import java.util.Scanner;

public class ReverseNum {
	

	public static void main(String[] args) {
		//int n=475;
		 int rev=0,rem;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a num");
		int n = sc.nextInt();
		
		while(n!=0) {
			
		
		rem=n%10;
		rev=(rev*10)+rem;
		n=n/10;}
		
		System.out.println(rev);
		

	}

}
