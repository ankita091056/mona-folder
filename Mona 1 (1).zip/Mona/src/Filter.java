
import java.util.ArrayList;

import java.util.Collections;

public class Filter {

	public static void main(String[] args) {
		int n[] = { 3, 5, 23, 22, 78, 19, 90, 232 };
		for (int i = 0; i < n.length; i++) {
			if (n[i] % 2 == 0) {
				System.out.println(n[i] + ": even number");
			} 
			}
		}
	}

	

	