import java.util.Arrays;
import java.util.Collections;

public class Sortingsort {
//	public static void main(String[] args) {
////		String[] fruits = {"banana","apple","grapes","watermelon","fig"};
////		Arrays.sort(fruits,Collections.reverseOrder());
////		System.out.println(Arrays.toString(fruits));
//		
//		
//		String [] name= {"smita","nisha","ankita","sheethal","nandini"};
//		Arrays.sort(name,Collections.reverseOrder());
//		System.out.println(Arrays.toString(name));
//	}
//
//}
	
//	class Sort {
	    public static void main(String args[]){
	    String str []={"acc","cap","epam"};
	    Arrays.sort(str);
	    System.out.println(Arrays.toString(str));
	    
	    Integer[] i =new Integer[] {2,4,0,1,56,23,4};
	    Arrays.sort(i);
	    System.out.println(Arrays.toString(i));
	    
	}}


