
public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="Smita";
        String rev= " ";
        char ch ;
        //System.out.println("Original String : ");
        //System.out.println("Smita");

        for(int i=str.length()-1; i>=0;i--) {
            ch=str.charAt(i);
            rev=rev+ch;


        }
        System.out.println("Reverse Word : " +rev);




    }

 

}