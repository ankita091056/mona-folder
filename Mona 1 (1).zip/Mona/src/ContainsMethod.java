
public class ContainsMethod {

	public static void main(String[] args) {

		// TODO Auto-generated method stub

//          Input the first string:

//                 Java

//                Input the second string:

//                 Ja

		String str = "Java";

		String str2 = "Ja";

		if (str.contains(str2)) {

			System.out.println("True");

		}

		else {

			System.out.println("False");

		}

	}

}
