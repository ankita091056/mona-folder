


public class MaxMinElement {

public static void main(String[] args) {

     int a[]= {2,3,5,6,6,7,4,3,9};

//     Arrays.sort(a);

     int size = a.length;

     int max = a[size - 1];      

        int min =a[0];    

     for(int i=0;i<size;i++) {

         int temp=0;

         for(int j =i+1;j<size;j++) {

             if(a[i]>a[j]) {

                temp= a[i];

                a[i]=a[j];

                a[j]=temp;

             }

         }

 

     

     System.out.println("Sorting element in ascending order:"+a[i]);

     }

    System.out.println("min value:"+min);

    System.out.println("max value:"+max);


     }

}
