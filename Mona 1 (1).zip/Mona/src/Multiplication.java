import java.util.Scanner;

public class Multiplication {

	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("enter a num");
//		int a=sc.nextInt();
//		System.out.println(a*1);
//		System.out.println(a*2);
//		System.out.println(a*3);
//		System.out.println(a*4);
//		System.out.println(a*5);
//		System.out.println(a*6);
//		System.out.println(a*7);
//		System.out.println(a*8);
//		System.out.println(a*9);
//		System.out.println(a*10);
		int n=10;
		int a=2;
		for( int i=1;i<=n;i++) {
			System.out.println(a+"*"+i+"="+a*i);
			
			
		}
	}

}
