

	import java.util.Scanner;
	import java.util.StringTokenizer;
	public class Username {
	  public static void main(String[] args) {
	    Scanner sc = new Scanner(System.in);
	    
	    String s1 = sc.nextLine();
	    getvalues(s1);
	  }
	  public static void getvalues(String s1) {
	    StringTokenizer st = new StringTokenizer(s1, "@");
	    String s2 = st.nextToken();
	    System.out.println(s2);
	  }
	}


