
import java.util.ArrayList;
import java.util.List;

public class MissingNo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> al = new ArrayList<Integer>();

		al.add(1);
		al.add(2);
		al.add(3);
		al.add(5);
		al.add(7);

		for (int i = 1; i < 8; i++) {
			if (al.contains(i)) {
				continue;
			} else {
				System.out.println(i);
			}
		}
	}

}
