import java.util.Scanner;

public class Fibonoci_Series {
	// by using scanner class

	public static void main(String[] args) {

		int n, a = 0, b = 1, c=0;
		Scanner sc = new Scanner(System.in);

		System.out.println("enter value of n");
		n = sc.nextInt();

		System.out.print("fibonacci series");

		for (int i = 0; i <= n; i++) {
			c = a + b;
			a = b;
			b = c;
			
			System.out.println(a + " ");
		}

	}

}
