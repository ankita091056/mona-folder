import java.util.Arrays;
import java.util.Collections;

public class DescInt {

	
	
	public static void main(String[] args) {
		Integer [] cubes= new Integer[] {77,88,99,44,76,44};
		Arrays.sort(cubes,Collections.reverseOrder());
		System.out.println(Arrays.toString(cubes));

	}

}
