import java.util.Arrays;

public class Third {
public static void main(String[] args) {
	int[] a= {1,2,3,4,5};
	System.out.println("Third largest number is "+thirdLargestNumber(a,6));
}
public static int thirdLargestNumber(int[] a,int total) {
	Arrays.sort(a);
		return a[total-3];
	}
}

