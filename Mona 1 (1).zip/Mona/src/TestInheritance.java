
public class TestInheritance {

}
