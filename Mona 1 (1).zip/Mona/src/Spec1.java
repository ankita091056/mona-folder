import java.util.Scanner;

public class Spec1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String ");
		String str=sc.next();
		System.out.println("Enter char");
		char c=sc.next().charAt(0);

		//String str = "capgemini";
		//char c = ('i');
		int count = 0;

		for (int i = 0; i < str.length(); i++) {

			if (str.charAt(i) == c) {
				count++;

			}
		}

		System.out.println(count);

	}

}
