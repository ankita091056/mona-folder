
interface InterfaceA {
    void methodA();
}

interface InterfaceB {
    void methodB();
}

class MyClass implements InterfaceA, InterfaceB {
    @Override
    public void methodA() {
        System.out.println("Implementation of methodA");
    }

    @Override
    public void methodB() {
        System.out.println("Implementation of methodB");
    }
}

public class MultipleInheritance {
    public static void main(String[] args) {
        MyClass myObj = new MyClass();
        myObj.methodA(); // Output: Implementation of methodA
        myObj.methodB(); // Output: Implementation of methodB
    }
}