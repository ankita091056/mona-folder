
import java.util.Arrays;
import java.util.List;

public class NewPrime {

	public static void main(String[] args) {

		List<Integer> numbers = Arrays.asList(3, 5, 23, 22, 78, 19, 90, 232);

		for (Integer num : numbers) {

			if (prime(num)) {
				System.out.print(num +" ");
			}
		}
	}

	public static boolean prime(int n) {
		if (n <= 1) {
			return false;
		}
		for (int i = 2; i <= Math.sqrt(n); i++) {
			if (n % i == 0) {
				return false;
			}
		}
		return true;
	}
}