
public class Variable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    String name="Smita";
    int age =24;
    float s=3.04f;
    double d= 200.00d;
    long l= 38937347;
    char c= 'A';
    System.out.println(name);
    System.out.println(age);
    System.out.println(s);
    System.out.println(d);
    System.out.println(l);
    System.out.println(c);
    
    
	}

}
