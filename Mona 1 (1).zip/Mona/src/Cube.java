import java.util.Scanner;

public class Cube {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number");
	     int i=sc.nextInt();
		//int cube = 3;
		System.out.println(i*i*i);
	}

}
