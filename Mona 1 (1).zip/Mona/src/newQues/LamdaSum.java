package newQues;


	public class LamdaSum {
	    public static void main(String[] args) {
	        // Lambda expression to calculate the sum of two integers
	        SumCalculator sumCalculator = (a, b) -> a + b;

	        int num1 = 5;
	        int num2 = 3;

	        int sum = sumCalculator.calculateSum(num1, num2);

	        System.out.println("The sum of " + num1 + " and " + num2 + " is: " + sum);
	    }

	    interface SumCalculator {
	        int calculateSum(int a, int b);
	    }
	}
	









