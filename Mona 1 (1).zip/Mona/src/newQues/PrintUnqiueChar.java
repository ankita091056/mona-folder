package newQues;

public class PrintUnqiueChar {

	
		  public static void main(String[] args) {
		        String str = "abcab";
		 
		        for (int i = 0; i < str.length(); i++) {
		            int num = 0;
		            for (int j = 0; j < str.length(); j++) {
		 
		                if (str.charAt(i) == str.charAt(j) && i != j) {
		                    num = 1;
		                    break;
		                }
		            }
		            if (num == 0)
		                System.out.print(str.charAt(i));
		        }
		    }
		}


