package newQues;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

// Main.java
public class EvenOdd {
    public static void main(String args[]) {


    List<Integer >num =Arrays.asList( 11,78,90,45,67,45);
        System.out.println("Original Numbers");
        for(int i :num) {
            System.out.print(i+ " ");


        }
        List evenNumbers= num.stream()

        .filter(n-> n%2==0)
        .collect(Collectors.toList());

        //it prints the 
        System.out.println(" \n Even Numbers are : " +evenNumbers);

 

    
    List oddNumbers = num.stream()
            .filter(n-> n%2==1)
            .collect(Collectors.toList());
    System.out.println(" \n odd Numbers : " +oddNumbers);


 

}

}