package newQues;

public class StringImmutable {
	
	    public static void main(String[] args) {
	        String str = "Hello";

	        // Perform operations on the string
	        String modifiedStr = str.concat(" World");
	        String substring = str.substring(1, 3);
	        String replacedStr = str.replace('H', 'J');

	        // Print the original string and modified strings
	        System.out.println("Original string: " + str);
	        System.out.println("Concatenated string: " + modifiedStr);
	        System.out.println("Substring: " + substring);
	        System.out.println("Replaced string: " + replacedStr);
	    }

}
