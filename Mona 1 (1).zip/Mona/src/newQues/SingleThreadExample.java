package newQues;

public class SingleThreadExample {

	
	
	    public static void main(String[] args) {
	        System.out.println("Main thread starts.");

	        // Perform some work in the main thread
	        System.out.println("Main thread is executing some tasks.");

	        // Simulate a delay in the main thread
	        try {
	            Thread.sleep(2000);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }

	        // Continue with the main thread
	        System.out.println("Main thread finishes.");
	    }
	}
