package newQues;

public class NullPointerException {
	 
		   public static void main(String[] args) {
		      Object ref = null;
		      ref.toString(); // this will throw a NullPointerException
		   }
		}



