package newQues;

public class Overloading {
	  
		static int add(int a,int b){return a+b;}  
		static int add(int a,int b,int c){return a+b+c;}  
		}  
		
		class Pets{  
		void eating(){System.out.println("eating...");}  
		}  
		class Cat extends Animal{  
		void eating(){System.out.println("eating bread...");}  


}
