package newQues;



	import java.util.ArrayList;
	import java.util.Arrays;
	import java.util.List;

	 

	public class DuplicateList {
		 
	    public static void main(String[] args) {
	        List<Integer> nums=Arrays.asList(1,2,3,4,5,2,4);

	        System.out.println(nums);

	        List<Integer> uniqueNums= new ArrayList<>();

	        nums.stream().distinct().forEach(uniqueNums::add);

	        System.out.println(uniqueNums);
	    }

	 

	}


