package newQues;


	import java.util.function.Predicate;
	public class EmptyString {

	
//	    public static void main(String[] args) {
//	        // Lambda expression to check if a given string is empty
//	        Predicate isEmptyString = str -> ((String) str).isEmpty();
//
//	        // Test cases
//	        String str1 = ""; // empty string
//	        String str2 = "Java lambda expression!"; // non-empty string
//
//	        // Check if the strings are empty using the lambda expression
//			System.out.println("String 1:" + str1);
//	        System.out.println("String 1 is empty: " + isEmptyString.test(str1));
//	        System.out.println("\nString 2:" + str2);
//			System.out.println("String 2 is empty: " + isEmptyString.test(str2));
//	    }
//	}
	
	
	//2nd logic
	
	public static void main(String[] args) {
        // Define a lambda expression to check if a string is empty
        StringChecker stringChecker = str -> str.isEmpty();

        // Test the lambda expression
        String str1 = "";
        String str2 = "Hello, World!";

        System.out.println("Is str1 empty? " + stringChecker.check(str1));
        System.out.println("Is str2 empty? " + stringChecker.check(str2));
    }

    // Functional interface for string checking
    @FunctionalInterface
    interface StringChecker {
        boolean check(String str);
    }
}
//In this program, we define a functional interface called StringChecker
//with a single abstract method check, which takes a string as a parameter and
//returns a boolean value indicating whether the string is empty or not.
//
//Next, we create a lambda expression using the str -> str.isEmpty() syntax. This lambda expression
//takes a string str as input and checks if it is empty using the isEmpty() method of the String class. 
//The expression returns true if the string is empty and false otherwise.
//
//In the main method, we demonstrate the usage of the lambda expression.
//
//We assign the lambda expression to an instance of the StringChecker functional interface. 
//Then, we pass different strings to the check method, which invokes the lambda expression and returns the result
//. Finally, we print the results.









	

