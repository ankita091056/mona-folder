package xyz;

public class ThirdLargestValue {

	public static int getThirdLargestValue(int a[], int total) {
		int temp;

		for (int i = 0; i <= total; i++) {
			for (int j = i + 1; j <= total; j++) {

				if (a[i] > a[j]) {
					temp = a[i];
					a[j] = a[j];
					a[j] = temp;

				}
			}

		}

		return a[total - 3];

	}

	public static void main(String[] args) {

		int a[] = { 2, 4, 6, 8, 9 };
		int b[] = { 6, 47, 83, 82, 8 };
		System.out.println(getThirdLargestValue(a, 4));
		System.out.println(getThirdLargestValue(b, 4));

	}

}
