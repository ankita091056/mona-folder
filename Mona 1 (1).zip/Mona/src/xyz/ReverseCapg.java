package xyz;

public class ReverseCapg {

	public static void main(String[] args) {
	//	String str="capgemini";
//		String rev="";
//		char ch;
//		
//		for (int i =  str.length()-1; i>=0; i--) {
//		ch=str.charAt(i);
//		rev=rev+ch;
//			
//		}
//		
//		System.out.println(rev);
//		
//	}
//}
		
 String str="capgemini";
	String sb=new StringBuilder(str).reverse().toString();
	System.out.println(sb);
	}}


