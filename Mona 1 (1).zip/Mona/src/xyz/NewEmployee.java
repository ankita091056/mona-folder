package xyz;

	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.Comparator;
	import java.util.List;
	import java.util.Scanner;

	class Employee {
	    private String name;
	    private String designation;
	    private int salary;

	    public Employee(String name, String designation, int salary) {
	        this.name = name;
	        this.designation = designation;
	        this.salary = salary;
	    }

	    public String getName() {
	        return name;
	    }

	    public String getDesignation() {
	        return designation;
	    }

	    public int getSalary() {
	        return salary;
	    }
	}

	public class NewEmployee {
	    private List<Employee> employees;

	    public NewEmployee () {
	        employees = new ArrayList<>();
	    }

	    public void acceptEmployeeDetails() {
	        Scanner scanner = new Scanner(System.in);
	        while (true) {
	            System.out.print("Enter the Name of employee (or 'q' to exit): ");
	            String name = scanner.nextLine();
	            if (name.equals("q")) {
	                break;
	            }
	            System.out.print("Enter the Designation: ");
	            String designation = scanner.nextLine();
	            System.out.print("Enter Salary: ");
	            int salary = scanner.nextInt();
	            scanner.nextLine(); // Consume the remaining newline character
	            employees.add(new Employee(name, designation, salary));
	        }
	    }

	    public void displayTopEarners() {
	        Collections.sort(employees, Comparator.comparingInt(Employee::getSalary).reversed());

	        System.out.println("\nTop 3 earners in the department are:");
	        System.out.println("Name\t\tDesignation\tSalary");
	        int count = 0;
	        for (Employee employee : employees) {
	            System.out.printf("%s\t\t%s\t\t%d%n", employee.getName(), employee.getDesignation(), employee.getSalary());
	            count++;
	            if (count == 3) {
	                break;
	            }
	        }
	    }

	    public static void main(String[] args) {
	    	NewEmployee  ems = new NewEmployee ();
	        Scanner scanner = new Scanner(System.in);

	        while (true) {
	            System.out.println("\nSample Menu:");
	            System.out.println("1 – Accept Employee Details");
	            System.out.println("2 – Display top 3 earners");
	            System.out.println("3 – Exit");
	            System.out.print("Please select the menu option: ");

	            int option = scanner.nextInt();
	            scanner.nextLine(); // Consume the remaining newline character

	            switch (option) {
	                case 1:
	                    ems.acceptEmployeeDetails();
	                    break;
	                case 2:
	                    ems.displayTopEarners();
	                    break;
	                case 3:
	                    System.exit(0);
	                    break;
	                default:
	                    System.out.println("Invalid option. Please try again.");
	            }
	        }
	    }
	}



