package xyz;

public class RemoveSpecialCharLower {
	
	    public static void main(String[] args) {
	        String inputString = "hello@world!";
	        String resultString = inputString.replaceAll("[^a-z]", "");
	        System.out.println("Input String: " + inputString);
	        System.out.println("Result String: " + resultString);
	    }
	}


