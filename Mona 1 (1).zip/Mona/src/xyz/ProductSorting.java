package xyz;


	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.Comparator;
	import java.util.List;

	class Product1 {
	    private int productId;
	    private String productName;

	    public Product1(int productId, String productName) {
	        this.productId = productId;
	        this.productName = productName;
	    }

	    public int getProductId() {
	        return productId;
	    }

	    public void setProductId(int productId) {
	        this.productId = productId;
	    }

	    public String getProductName() {
	        return productName;
	    }

	    public void setProductName(String productName) {
	        this.productName = productName;
	    }
	}

	public class ProductSorting{
	    public static void main(String[] args) {
	        // Create a list to store Product objects
	        List<Product> productList = new ArrayList<>();

	        // Add products to the list
	        productList.add(new Product(1, "Keyboard"));
	        productList.add(new Product(2, "Mouse"));
	        productList.add(new Product(3, "fridze"));
	        productList.add(new Product(4, "Speaker"));

	        // Sort the list by ProductName in ascending order
	        Collections.sort(productList, Comparator.comparing(Product::getProductName));

	        // Print the sorted products
	        System.out.println("Sorted Products (by ProductName):");
	        for (Product product : productList) {
	            System.out.println("Product ID: " + product.getProductId() + ", Product Name: " + product.getProductName());
	        }
	    }
	}



