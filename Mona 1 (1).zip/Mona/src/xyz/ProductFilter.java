package xyz;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Product {
    private int productId;
    private String productName;

    public Product(int productId, String productName) {
        this.productId = productId;
        this.productName = productName;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
}

public class ProductFilter {
    public static void main(String[] args) {
        // Create a list to store Product objects
        List<Product> productList = new ArrayList<>();

        // Add products to the list
        productList.add(new Product(1, "Keyboard"));
        productList.add(new Product(2, "Mouse"));
        productList.add(new Product(3, "Monitor"));
        productList.add(new Product(4, "Speaker"));
        productList.add(new Product(4, "Smartwatch"));

        // Filter products whose names start with 'S'
        List<Product> filteredProducts = productList.stream()
                .filter(product -> product.getProductName().startsWith("S"))
                .collect(Collectors.toList());

        // Print the filtered products
        System.out.println("Filtered Products (Names starting with 'S'):");
        for (Product product : filteredProducts) {
            System.out.println("Product ID: " + product.getProductId() + ", Product Name: " + product.getProductName());
        }
    }
}
