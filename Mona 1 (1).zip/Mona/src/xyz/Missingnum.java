package xyz;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Missingnum {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>(Arrays.asList(2, 4, 6, 10, 12, 14, 16, 18, 20));

		Collections.sort(list);

		for (int i = 1; i < list.get(list.size() - 1); i++) {
			if (list.contains(i)) {
				continue;
			} else {
				System.out.println(i);
			}
		}

	}
}
