package xyz;

public class Palindrome {

	public static void main(String[] args) {
		String str="MADAM";
		StringBuffer sb=new StringBuffer(str);
		if(sb.reverse().toString().equals(str)){
			System.out.println("string is palindrome");
		}
		else {
			System.out.println("String is not palindrome");
		}


	}

}
