package xyz;

public class SwapNum {
	
	    public static void main(String[] args) {
	        int number1 = 10;
	        int number2 = 20;

	        System.out.println("Before swapping:");
	        System.out.println("Number 1: " + number1);
	        System.out.println("Number 2: " + number2);

	        // Swapping the numbers
	        int temp = number1;
	        number1 = number2;
	        number2 = temp;

	        System.out.println("\nAfter swapping:");
	        System.out.println("Number 1: " + number1);
	        System.out.println("Number 2: " + number2);
	    }
	}



