package xyz;

public class CountSpecialChar {

	    public static int countSpecialCharacters(String str) {
	        return str.replaceAll("[a-zA-Z0-9_]", "").length();
	    }

	    public static void main(String[] args) {
	        String inputString = "anu-sri.kondeti@capgemini.com";
	        int specialCharacterCount = countSpecialCharacters(inputString);
	        System.out.println("Number of special characters: " + specialCharacterCount);
	    }
	}